# Agla kaam: Stage 6 original perturbation result inventory

1. Colab open karo: https://colab.research.google.com/
2. `HAR_Stage6_Find_Perturbation_Effect_Files_Colab.ipynb` upload karo.
3. Runtime -> Run all.
4. `HAR_Stage6_Source_Inventory.zip` download hoga, ise isi chat mein upload kar dena.
5. Agar GEO directory blocked ho aur inventory khali ho, to GSE270828 ke Supplementary files ki screenshot bhej dena: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270828

Is notebook ka kaam sirf original file listing aur small likely tables retrieve karna hai. Biological stats abhi calculate nahi honge. Is stage mein koi 2-GB single-cell data manually download na karein.
