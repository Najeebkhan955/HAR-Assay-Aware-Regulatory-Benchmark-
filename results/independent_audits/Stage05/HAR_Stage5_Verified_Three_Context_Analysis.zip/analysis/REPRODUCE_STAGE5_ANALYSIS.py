#!/usr/bin/env python3
"""Stage 5: Three-context HAR-bait identifier and reported-contact audit.

NO claim of measured perturbation effects, enhancer-gene mapping, or causal
human-lineage evolutionary gains/losses. Chimp genome coordinate comparisons
are intentionally NOT performed. Labels, not genomic coordinates, align species.

Requires: Python 3, pandas, numpy, matplotlib. Workbook produced separately.
"""
from pathlib import Path
from collections import defaultdict
import json, hashlib, re, zipfile, io, itertools
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path('/mnt/data')
OUT=ROOT/'HAR_Stage5_Three_Context_Audit'
OUT.mkdir(exist_ok=True)
SOURCES={
  'human_NSC':'HAR_interactions_hNSCs.txt',
  'human_neuron':'HAR_interactions_human_neurons.txt',
  'chimp_NSC':'HAR_interactions_cNSCs.txt',
}
GUIDE_ZIP=ROOT/'GSE270828_Full_Guide_Reference_FOR_REVIEW.zip'
RE_SUFFIX=re.compile(r'(?:_sec|_tert)$')
PAL_COLS=['Bait_chr','Bait_start','Bait_end','Bait_name','OtherEnd_chr','OtherEnd_start','OtherEnd_end','CHiCAGO_score']
BAIT_COLS=PAL_COLS[:4]
EDGE_COLS=PAL_COLS[:3]+['Bait_name']+PAL_COLS[4:7]

def base(token):return RE_SUFFIX.sub('',token.strip())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(df,name):df.to_csv(OUT/name,sep='\t',index=False)
def token_match_kind(token,original,n):
    if token != n: return 'flanking' # due _sec/_tert suffix
    return 'exact' if original==n else 'composite'

def audit():
 with zipfile.ZipFile(GUIDE_ZIP) as z:
    guide_bytes=z.read('GSE270828_feature_README.csv')
 guides=pd.read_csv(io.BytesIO(guide_bytes))
 target=guides[~guides.name.str.startswith(('NTC','cont_'))].copy()
 names=set(target.name.unique());assert len(names)==180
 genes=target.drop_duplicates('name')[['name','target_gene_id','target_gene_name']].set_index('name')
 assert all(target.groupby('name').target_gene_name.nunique()==1)
 all_rows=[];all_edges={};per_har={};source_qc=[]
 for context,fn in SOURCES.items():
    fn=ROOT/fn
    df=pd.read_csv(fn,sep='\t')
    assert list(df.columns)==PAL_COLS,(context,df.columns.tolist())
    assert df.notna().all().all() and (df.Bait_start<df.Bait_end).all() and (df.OtherEnd_start<df.OtherEnd_end).all()
    assert (df.Bait_chr==df.OtherEnd_chr).all()
    assert not df.duplicated().any()
    # Aggregate per HAR, source row may be shared among composite labels.
    counts=defaultdict(list)
    unique_matched_rowidx=set()
    for i,b in enumerate(df.Bait_name):
       for tok in str(b).split(','):
          tok=tok.strip();n=base(tok)
          if n not in names:continue
          kind=token_match_kind(tok,b,n)
          counts[n].append((i,kind,tok))
          unique_matched_rowidx.add(i)
          all_rows.append({
              'context':context,'source_line':i+2,'har_label':n,'bait_match_type':kind,
              'Bait_chr':df.iloc[i]['Bait_chr'],'Bait_start':int(df.iloc[i]['Bait_start']),
              'Bait_end':int(df.iloc[i]['Bait_end']),'Bait_name':b,
              'OtherEnd_chr':df.iloc[i]['OtherEnd_chr'],'OtherEnd_start':int(df.iloc[i]['OtherEnd_start']),
              'OtherEnd_end':int(df.iloc[i]['OtherEnd_end']),'CHiCAGO_score':float(df.iloc[i]['CHiCAGO_score']),
          })
    result={}
    for n in sorted(names):
       hits=counts[n]
       if not hits:tier='not identified'
       elif any(k=='exact' for _,k,_ in hits):tier='exact bait-name'
       elif any(k=='composite' for _,k,_ in hits):tier='composite bait-name'
       else:tier='flanking fragment only'
       idxs=sorted(set(i for i,_,_ in hits))
       part=df.iloc[idxs] if idxs else df.iloc[0:0]
       kinds={i for i,k,_ in hits if k!='flanking'}
       result[n]={
          'match_tier':tier,'any_name_match':bool(hits),
          'core_name_match':bool(kinds),
          'n_contact_rows':len(idxs),
          'n_bait_fragments':int(part[BAIT_COLS].drop_duplicates().shape[0]),
          'n_contacts_ge5':int((part.CHiCAGO_score>=5).sum()),
          'n_contacts_ge7':int((part.CHiCAGO_score>=7).sum()),
          'n_contacts_ge10':int((part.CHiCAGO_score>=10).sum()),
          'max_score':round(float(part.CHiCAGO_score.max()),3) if len(part) else None,
          'median_score':round(float(part.CHiCAGO_score.median()),3) if len(part) else None,
       }
    per_har[context]=result
    all_edges[context]=df.iloc[sorted(unique_matched_rowidx)].copy()
    source_qc.append({
       'context':context,'original_filename':fn.name,'sha256':sha(fn),
       'original_contact_rows':len(df),'distinct_original_bait_labels':df.Bait_name.nunique(),
       'distinct_bait_fragments':int(df[BAIT_COLS].drop_duplicates().shape[0]),
       'distinct_screened_HAR_labels_matched':sum(x['any_name_match'] for x in result.values()),
       'distinct_core_matched_HAR_labels':sum(x['core_name_match'] for x in result.values()),
       'unique_original_source_rows_with_screened_label':len(unique_matched_rowidx),
       'screened_source_contact_rows_ge5':int((all_edges[context].CHiCAGO_score>=5).sum()),
       'screened_source_contact_rows_ge7':int((all_edges[context].CHiCAGO_score>=7).sum()),
       'min_score_original':float(df.CHiCAGO_score.min()),'max_score_original':float(df.CHiCAGO_score.max()),
       'missing_cells':int(df.isna().sum().sum()),'duplicate_original_rows':int(df.duplicated().sum()),
       'is_all_cis':bool((df.Bait_chr==df.OtherEnd_chr).all()),
    })
 source_qc=pd.DataFrame(source_qc)
 write(source_qc,'S1_Source_QC_and_Provenance.tsv')
 # Each of 180 guide names is a distinct row, regardless of any contact evidence.
 wide=[]
 for n in sorted(names):
    rec={'har_label':n,'guide_design_gene_annotation':genes.loc[n,'target_gene_name'],
         'guide_design_ensembl_id':genes.loc[n,'target_gene_id'],
         'n_screening_guides':int((target.name==n).sum())}
    for context in SOURCES:
       for k,v in per_har[context][n].items():rec[f'{context}_{k}']=v
    rec['matched_all_three_names']=all(per_har[c][n]['any_name_match'] for c in SOURCES)
    rec['matched_all_three_core_names']=all(per_har[c][n]['core_name_match'] for c in SOURCES)
    rec['present_human_NSC_and_human_neuron']=per_har['human_NSC'][n]['any_name_match'] and per_har['human_neuron'][n]['any_name_match']
    rec['name_pattern']=''.join('1' if per_har[c][n]['any_name_match'] else '0' for c in SOURCES)
    rec['has_independent_functional_gene_target_validation_here']=False
    wide.append(rec)
 wide=pd.DataFrame(wide)
 write(wide,'S2_All_180_HAR_Three_Context_Audit.tsv')
 ann=pd.DataFrame(all_rows)
 ann['contact_report_not_a_gene_target_validation']=True
 write(ann,'S3_Annotated_Original_Contact_Rows_by_HAR_Label.tsv')
 thresholds=[]
 for context,df in all_edges.items():
    for condition,threshold in [('all_reported',None),('CHiCAGO >= 5',5),('CHiCAGO >= 7',7),('CHiCAGO >= 10',10)]:
       sub=df if threshold is None else df.loc[df.CHiCAGO_score>=threshold]
       present=set()
       core=set()
       for b in sub.Bait_name:
          for tok in b.split(','):
             n=base(tok)
             if n in names:
                present.add(n)
                if tok==n:core.add(n)
       thresholds.append({'context':context,'threshold':condition,'source_rows_passing':len(sub),
                          'n_HARs_name_covered':len(present),'n_HARs_core_name_covered':len(core),
                          'fraction_180_name_covered':round(len(present)/180,6),
                          'interpretation':'Descriptive coverage. Counts/scores are not normalized effect sizes.'})
 th=pd.DataFrame(thresholds);write(th,'S4_Contact_Score_Threshold_Sensitivity.tsv')
 patterns=wide.groupby('name_pattern').size().rename('n_HARs').reset_index().sort_values('n_HARs',ascending=False)
 patterns['human_NSC_name']=patterns.name_pattern.str[0].eq('1')
 patterns['human_neuron_name']=patterns.name_pattern.str[1].eq('1')
 patterns['chimp_NSC_name']=patterns.name_pattern.str[2].eq('1')
 write(patterns,'S5_Name_Coverage_Patterns.tsv')
 # Within human genome only, compare exact bait fragment and target fragment coordinates.
 A=all_edges['human_NSC']; B=all_edges['human_neuron'];
 E_A=set(map(tuple,A[EDGE_COLS].itertuples(index=False,name=None)))
 E_B=set(map(tuple,B[EDGE_COLS].itertuples(index=False,name=None)))
 exactpairs=E_A&E_B
 exact_shared=pd.DataFrame(list(exactpairs),columns=EDGE_COLS).sort_values(EDGE_COLS).reset_index(drop=True)
 sa=A[EDGE_COLS+['CHiCAGO_score']].rename(columns={'CHiCAGO_score':'CHiCAGO_score_hNSC'})
 sb=B[EDGE_COLS+['CHiCAGO_score']].rename(columns={'CHiCAGO_score':'CHiCAGO_score_neuron'})
 exact_shared=exact_shared.merge(sa,on=EDGE_COLS,validate='one_to_one').merge(sb,on=EDGE_COLS,validate='one_to_one')
 exact_shared['both_have_reported_contact_but_not_independent_biological_replication']=True
 write(exact_shared,'S6_Exact_Human_Bait_and_Distal_Contact_Pairs_Shared.tsv')
 baitA=set(map(tuple,A[BAIT_COLS].itertuples(index=False,name=None)))
 baitB=set(map(tuple,B[BAIT_COLS].itertuples(index=False,name=None)))
 shared_baits=baitA&baitB
 baitstats=[]
 for tup in sorted(baitA|baitB):
    aa=A.loc[np.logical_and.reduce([A[c].eq(v).to_numpy() for c,v in zip(BAIT_COLS,tup)])]
    bb=B.loc[np.logical_and.reduce([B[c].eq(v).to_numpy() for c,v in zip(BAIT_COLS,tup)])]
    # Distal exact intervals, same human coordinate system. One interval unique per bait.
    destcols=['OtherEnd_chr','OtherEnd_start','OtherEnd_end']
    aa_set=set(map(tuple,aa[destcols].itertuples(index=False,name=None)))
    bb_set=set(map(tuple,bb[destcols].itertuples(index=False,name=None)))
    baitstats.append(dict(zip(BAIT_COLS,tup),**{
      'source_edges_hNSC':len(aa_set),'source_edges_neuron':len(bb_set),
      'n_exact_distal_pairs_shared':len(aa_set&bb_set),
      'jaccard_exact_distal_pairs':round(len(aa_set&bb_set)/len(aa_set|bb_set),6),
      'bait_reported_in_both':bool(aa_set) and bool(bb_set),
      'no_independent_replicate_variance':True,
    }))
 bs=pd.DataFrame(baitstats)
 write(bs,'S7_Human_Exact_Bait_Fragment_Concordance.tsv')
 missed=wide.loc[~wide.matched_all_three_names,['har_label','guide_design_gene_annotation','name_pattern','human_NSC_match_tier','human_neuron_match_tier','chimp_NSC_match_tier']]
 write(missed,'S8_HAR_Labels_Not_Covered_In_All_Three.tsv')
 # 164 gene-level labels from the guide design; no validated HAR-target gene assertions.
 gl=wide.groupby('guide_design_gene_annotation',dropna=False,as_index=False).agg(
    n_screened_HARs=('har_label','nunique'),
    n_HAR_labels_matched_all_three=('matched_all_three_names','sum'),
    HAR_labels=('har_label',lambda x:';'.join(x)))
 gl['gene_label_is_guide_design_annotation_only']=True
 write(gl,'S9_Guide_Design_Gene_Annotations_Not_Validated.tsv')
 # Source raw contact provenance and summary
 a,b,c=(set(wide.loc[wide[f'{ctx}_any_name_match'],'har_label']) for ctx in SOURCES)
 summary={
   'n_screened_HAR_labels':180,
   'human_NSC_name_matched':len(a),'human_neuron_name_matched':len(b),'chimp_NSC_name_matched':len(c),
   'matched_all_three_names':len(a&b&c),
   'matched_human_NSC_and_neuron':len(a&b),
   'matched_human_NSC_and_chimp_NSC':len(a&c),
   'matched_human_neuron_and_chimp_NSC':len(b&c),
   'human_NSC_source_contact_rows_matched':len(A),
   'human_neuron_source_contact_rows_matched':len(B),
   'chimp_NSC_source_contact_rows_matched':len(all_edges['chimp_NSC']),
   'human_matching_source_bait_fragments_hNSC':len(baitA),
   'human_matching_source_bait_fragments_neuron':len(baitB),
   'human_shared_exact_bait_fragments':len(shared_baits),
   'human_shared_exact_bait_and_distal_fragment_pairs':len(exactpairs),
   'human_exact_edge_jaccard':round(len(exactpairs)/len(E_A|E_B),6),
   'unique_screening_guide_design_genes':int(gl.shape[0]),
   'source_genome_cross_species_liftover_performed':False,
   'target_promoter_annotations_used':False,
   'perturbation_gene_effects_used':False,
   'comparative_contact_significance_inferred':False,
   'primary_caveat':'Bait names are shared metadata; context-specific contacts are conditional on library depth/capture and no independent replicate-level variances provided.',
   'source_sha256':{k:sha(ROOT/v) for k,v in SOURCES.items()},
   'guide_source_sha256':hashlib.sha256(guide_bytes).hexdigest(),
 }
 (OUT/'S0_Verified_Analysis_Summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
 assert len(a)==174 and len(b)==169 and len(c)==171 and len(a&b&c)==163
 assert len(A)==3331 and len(B)==1888 and len(all_edges['chimp_NSC'])==2438
 assert len(exactpairs)==129
 assert len(wide)==180 and len(gl)==164
 assert wide.har_label.is_unique
 assert (wide['matched_all_three_names']==(wide.name_pattern=='111')).all()
 # Figures: direct numerical data only, on white background.
 plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10.5,'axes.spines.top':False,'axes.spines.right':False,'axes.titleweight':'bold','savefig.facecolor':'white','figure.facecolor':'white','axes.facecolor':'white'})
 colors=['#1F5DA8','#0D9992','#9D6CD2']
 fig,ax=plt.subplots(figsize=(9.6,4.7),dpi=150)
 items=list(SOURCES); vals=[len(a),len(b),len(c)]
 rect=ax.barh([0,1,2],vals,color=colors,height=.6)
 ax.set_yticks([0,1,2],['Human neural stem cells','Human neurons','Chimpanzee neural stem cells']);ax.invert_yaxis()
 ax.set_xlim(0,203);ax.set_xlabel('GSE270828 screened HAR names with bait-identifier matches (of 180)')
 ax.set_title('Cross-context coverage of screened HAR bait identifiers',pad=15)
 for p,v in zip(rect,vals):ax.text(p.get_width()+2,p.get_y()+p.get_height()/2,f'{v}/180  ({v/180:.1%})',va='center',fontsize=10)
 ax.grid(axis='x',alpha=.14);ax.set_axisbelow(True)
 fig.text(.15,.015,'Identifier coverage only  |  Does not establish enhancer–gene activity or species-specific effects',fontsize=8.5,color='#555')
 fig.tight_layout(rect=[0,.05,1,1]);fig.savefig(OUT/'F1_Three_Context_HAR_Name_Coverage.png',dpi=340,bbox_inches='tight');fig.savefig(OUT/'F1_Three_Context_HAR_Name_Coverage.pdf',bbox_inches='tight');plt.close(fig)
 fig,ax=plt.subplots(figsize=(9.4,5.2),dpi=150)
 pat=patterns.sort_values('n_HARs',ascending=True)
 bars=ax.barh(pat.name_pattern,pat.n_HARs,color='#3577AE',height=.66)
 ax.set_xlabel('Number of screened HAR labels');ax.set_ylabel('Name-presence pattern (hNSC | neuron | cNSC)')
 ax.set_title('Shared and context-restricted HAR name coverage',pad=15)
 for p,v in zip(bars,pat.n_HARs):ax.text(p.get_width()+1,p.get_y()+p.get_height()/2,str(v),va='center')
 ax.set_xlim(0,max(pat.n_HARs)*1.16)
 ax.grid(axis='x',alpha=.12);ax.set_axisbelow(True)
 fig.text(.12,.012,'e.g. 111 = identifier present in all three; absence is not a biological negative',color='#555',fontsize=8.5)
 fig.tight_layout(rect=[0,.04,1,1]);fig.savefig(OUT/'F2_Shared_HAR_Name_Presence_Patterns.png',dpi=340,bbox_inches='tight');fig.savefig(OUT/'F2_Shared_HAR_Name_Presence_Patterns.pdf',bbox_inches='tight');plt.close(fig)
 fig,ax=plt.subplots(figsize=(7.6,6.2),dpi=150)
 x=wide.human_NSC_n_contact_rows.to_numpy();y=wide.human_neuron_n_contact_rows.to_numpy()
 ax.scatter(x+1,y+1,s=39,alpha=.65,edgecolors='white',linewidths=.4,c='#2563A1')
 mx=max(x.max(),y.max())+1
 ax.plot([1,mx],[1,mx],linestyle='--',color='#777',linewidth=1)
 ax.set_xscale('log');ax.set_yscale('log');ax.set_xlim(.9,mx*1.25);ax.set_ylim(.9,mx*1.25)
 ax.set_xlabel('Human NSC reported contact rows per screened HAR + 1')
 ax.set_ylabel('Human neuron reported contact rows per screened HAR + 1')
 ax.set_title('Descriptive contact-record differences across human cell contexts',pad=15)
 ax.grid(alpha=.16)
 fig.text(.13,.015,'Per-HAR counts are dependent on capture coverage; points are not biological replicates',fontsize=8.3,color='#555')
 fig.tight_layout(rect=[0,.04,1,1]);fig.savefig(OUT/'F3_Human_Context_Contact_Row_Comparison.png',dpi=340,bbox_inches='tight');fig.savefig(OUT/'F3_Human_Context_Contact_Row_Comparison.pdf',bbox_inches='tight');plt.close(fig)
 fig,ax=plt.subplots(figsize=(9.8,4.7),dpi=150)
 # exact human fragment comparability as conditional paired description
 cat=['Human NSC original edges','Human neuron original edges','Exact shared edges']
 counts=[len(E_A),len(E_B),len(exactpairs)]
 bb=ax.barh(cat[::-1],counts[::-1],color=['#3679A4','#44A897','#8986C2'][::-1],height=.62)
 for p,v in zip(bb,counts[::-1]):ax.text(p.get_width()+35,p.get_y()+p.get_height()/2,f'{v:,}',va='center')
 ax.invert_yaxis();ax.set_xlim(0,max(counts)*1.2)
 ax.set_xlabel('Distinct exact bait–distal-fragment coordinate pairs')
 ax.set_title('Exact human coordinate-level contact concordance',pad=15)
 ax.grid(axis='x',alpha=.13);ax.set_axisbelow(True)
 fig.text(.13,.012,f'{len(exactpairs):,} shared exact pairs · Jaccard {len(exactpairs)/len(E_A|E_B):.3f} · not a replicate-based differential-contact test',fontsize=8.4,color='#555')
 fig.tight_layout(rect=[0,.05,1,1]);fig.savefig(OUT/'F4_Exact_Human_Interaction_Concordance.png',dpi=340,bbox_inches='tight');fig.savefig(OUT/'F4_Exact_Human_Interaction_Concordance.pdf',bbox_inches='tight');plt.close(fig)
 # detailed scientific report
 md=f'''# Stage 5 — Three-context capture–Hi-C HAR name and fragment audit

## Provenance and quality controls

The original Pal et al. tables were analyzed in full: {source_qc.loc[0,'original_contact_rows']:,} human NSC, {source_qc.loc[1,'original_contact_rows']:,} human-neuron and {source_qc.loc[2,'original_contact_rows']:,} chimpanzee NSC interaction records. The GSE270828 original guide reference supplied {len(target)} guide records targeting 180 HAR names, plus controls. All interaction tables have exactly the eight expected columns; numeric scores and start/end positions were valid, and no rows were duplicated or missing. SHA256 checksums are provided in S1 and S0.

## Main descriptive findings

Among the **180 GSE270828 screened HAR names**, **{len(a)}** appeared in Pal human NSC, **{len(b)}** in human neurons, and **{len(c)}** in chimpanzee NSC bait names when exact, composite comma-separated and suffixed flank fragments were considered. **{len(a&b&c)} / 180** appeared in all three. These coverage frequencies are conditional on assay capture and the original CHiCAGO threshold; absence is not evidence of lack of interactions.

The named HARs were associated with {len(A):,}, {len(B):,}, and {len(all_edges['chimp_NSC']):,} unique input interaction rows in the respective conditions. These are NOT statistically independent biological samples, and unequal library depth makes total contact comparisons descriptive only. The same source interaction row may be annotated to >1 HAR under composite bait names; it must not be double-counted.

Between the two human conditions, {len(shared_baits)} exact genomic bait fragments were represented in both input subsets. Using *identical bait AND identical distal-fragment coordinates*, {len(exactpairs)} contact pairs were shared of {len(E_A|E_B)} distinct pooled pairs (descriptive Jaccard {len(exactpairs)/len(E_A|E_B):.4f}). The low exact overlap can reflect calling thresholds, input coverage and technical differences; it does NOT establish differential contacts, lack of regulatory stability or biological state effects.

For **chimpanzee NSCs**, genomic coordinates are from another species. We **do not intersect human and chimp chromosomal start/end positions**, label-based presence only. A valid genomic comparison would need proven orthology, build/coordinate harmonization, and comparable capture-design/technical replication. Even cross-species matching names do not establish orthologous enhancer–gene pairs.

## Statistical and interpretation boundaries

- This is a three-context, cross-study **metadata and interaction-table audit**, not new CRISPRi Perturb-seq experimental effect analysis.
- `target_gene_name` in the screen reference is a **guide-design annotation** and must NOT be counted as a transcriptional effect or confirmed HAR target.
- CHiCAGO interaction scores are contact detection statistics, not log2-fold changes or experimental regulatory effect sizes. CHiCAGO scores may have different calibration across capture conditions.
- Statistical comparisons of conditions require actual sample-level replicates and suitable normalization/latent contact-detection models. **No P values, confidence intervals or FDR are claimed here.**
- Human neuron/NSC source-edge Jaccard is an exact-fragment-identity sensitivity metric, not a statistical reproducibility coefficient.
- The per-HAR S2 is the authoritative 180-name comparison. S3 preserves original source row provenance. S4 quantifies thresholds of 5, 7, 10. S5 reports presence/absence patterns; S6/S7 report human coordinate-level descriptive concordance. S8 flags incompletely covered HAR names; S9 identifies design annotations only.

## Next research decision

**Priority: acquire published GSE270828 Perturb-seq gene-level outcomes** (ideally guide/cell/replicate-aware estimates, FDR and control information). Then benchmark contact-based HAR–gene prediction against measured responses, and avoid circularity where already used for original target nomination. Subsequent promoter coordinate annotations will be needed to map Pal distal fragments to candidate gene promoters; a contacted fragment alone is not a target gene.

Recommended scope for eventual paper: perturbation-grounded **validation and calibration** of cell-context HAR–gene links, rather than claiming novel human-specific causal maturation programs from name matches.
'''
 (OUT/'REPORT_Stage5_Results_Methods_Limitations.md').write_text(md,encoding='utf8')
 nexttxt='''# Agla step — Roman Urdu

Bhai, is stage mein teenon original Pal files ka full audit ho gaya. 180 screened HAR names mein 163 naam teeno conditions mein milte hain, lekin sirf naam milne se gene function prove nahi hota. Human–chimp genomic coordinates compare nahi kiye (genomes different hain).

**Ab sab se zaroori original biological file hai GSE270828 ka Perturb-seq transcriptomic-effect result.** Iske liye NCBI GEO GSE270828 ke supplementary section se gene-level differential-expression CSV/TSV ya study ke Zenodo/GitHub results chahiye, ideally with log2FC and FDR. Guide reference dubara na bhejein; woh already hai. Agar GEO mein sirf raw matrix/h5ad ho, uski file listing/screenshot share karein; main correct lightweight analysis route recommend karunga.

Original source page: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270828

Files yahan upload karne par main perturbation vs contact predictive benchmarking, leakage-aware baselines and confidence/uncertainty analyses karunga. Random gene assignment ya invented P values nahi dunga.
'''
 (OUT/'NEXT_STEPS_ROMAN_URDU.md').write_text(nexttxt,encoding='utf8')
 (OUT/'README_FIRST.md').write_text('''STAGE 5 — Verified three-context HAR label and contact concordance\n\nStart with REPORT_Stage5_Results_Methods_Limitations.md and S0_Verified_Analysis_Summary.json.\nS2 contains all 180 screened HAR labels. S3 contains contact-level annotated rows (with original source line numbers). S6/S7 describe human-only exact bait/other-end concordance. F1–F4 plots use the source data, NOT generated examples.\n\nLIMITATION: No causal enhancer–gene findings or experimental CRISPRi gene effects from these files. Cross-species coordinate intersections not performed.\n''',encoding='utf8')
 print(json.dumps({'source_qc':source_qc[['context','original_contact_rows','distinct_screened_HAR_labels_matched','unique_original_source_rows_with_screened_label']].to_dict('records'),'summary':summary,'patterns':patterns.to_dict('records')},indent=2))
 return summary
if __name__=='__main__':audit()
