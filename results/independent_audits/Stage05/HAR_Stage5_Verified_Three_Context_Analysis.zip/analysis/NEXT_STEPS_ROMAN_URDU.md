# Agla step — Roman Urdu

Bhai, is stage mein teenon original Pal files ka full audit ho gaya. 180 screened HAR names mein 163 naam teeno conditions mein milte hain, lekin sirf naam milne se gene function prove nahi hota. Human–chimp genomic coordinates compare nahi kiye (genomes different hain).

**Ab sab se zaroori original biological file hai GSE270828 ka Perturb-seq transcriptomic-effect result.** Iske liye NCBI GEO GSE270828 ke supplementary section se gene-level differential-expression CSV/TSV ya study ke Zenodo/GitHub results chahiye, ideally with log2FC and FDR. Guide reference dubara na bhejein; woh already hai. Agar GEO mein sirf raw matrix/h5ad ho, uski file listing/screenshot share karein; main correct lightweight analysis route recommend karunga.

Original source page: https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270828

Files yahan upload karne par main perturbation vs contact predictive benchmarking, leakage-aware baselines and confidence/uncertainty analyses karunga. Random gene assignment ya invented P values nahi dunga.
