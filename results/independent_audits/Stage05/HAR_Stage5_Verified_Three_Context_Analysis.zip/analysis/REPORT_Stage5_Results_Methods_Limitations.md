# Stage 5 — Three-context capture–Hi-C HAR name and fragment audit

## Provenance and quality controls

The original Pal et al. tables were analyzed in full: 39,093 human NSC, 21,415 human-neuron and 26,668 chimpanzee NSC interaction records. The GSE270828 original guide reference supplied 359 guide records targeting 180 HAR names, plus controls. All interaction tables have exactly the eight expected columns; numeric scores and start/end positions were valid, and no rows were duplicated or missing. SHA256 checksums are provided in S1 and S0.

## Main descriptive findings

Among the **180 GSE270828 screened HAR names**, **174** appeared in Pal human NSC, **169** in human neurons, and **171** in chimpanzee NSC bait names when exact, composite comma-separated and suffixed flank fragments were considered. **163 / 180** appeared in all three. These coverage frequencies are conditional on assay capture and the original CHiCAGO threshold; absence is not evidence of lack of interactions.

The named HARs were associated with 3,331, 1,888, and 2,438 unique input interaction rows in the respective conditions. These are NOT statistically independent biological samples, and unequal library depth makes total contact comparisons descriptive only. The same source interaction row may be annotated to >1 HAR under composite bait names; it must not be double-counted.

Between the two human conditions, 336 exact genomic bait fragments were represented in both input subsets. Using *identical bait AND identical distal-fragment coordinates*, 129 contact pairs were shared of 5090 distinct pooled pairs (descriptive Jaccard 0.0253). The low exact overlap can reflect calling thresholds, input coverage and technical differences; it does NOT establish differential contacts, lack of regulatory stability or biological state effects.

For **chimpanzee NSCs**, genomic coordinates are from another species. We **do not intersect human and chimp chromosomal start/end positions**, label-based presence only. A valid genomic comparison would need proven orthology, build/coordinate harmonization, and comparable capture-design/technical replication. Even cross-species matching names do not establish orthologous enhancer–gene pairs.

## Statistical and interpretation boundaries

- This is a three-context, cross-study **metadata and interaction-table audit**, not new CRISPRi Perturb-seq experimental effect analysis.
- `target_gene_name` in the screen reference is a **guide-design annotation** and must NOT be counted as a transcriptional effect or confirmed HAR target.
- CHiCAGO interaction scores are contact detection statistics, not log2-fold changes or experimental regulatory effect sizes. CHiCAGO scores may have different calibration across capture conditions.
- Statistical comparisons of conditions require actual sample-level replicates and suitable normalization/latent contact-detection models. **No P values, confidence intervals or FDR are claimed here.**
- Human neuron/NSC source-edge Jaccard is an exact-fragment-identity sensitivity metric, not a statistical reproducibility coefficient.
- The per-HAR S2 is the authoritative 180-name comparison. S3 preserves original source row provenance. S4 quantifies thresholds of 5, 7, 10. S5 reports presence/absence patterns; S6/S7 report human coordinate-level descriptive concordance. S8 flags incompletely covered HAR names; S9 identifies design annotations only.

## Next research decision

**Priority: acquire published GSE270828 Perturb-seq gene-level outcomes** (ideally guide/cell/replicate-aware estimates, FDR and control information). Then benchmark contact-based HAR–gene prediction against measured responses, and avoid circularity where already used for original target nomination. Subsequent promoter coordinate annotations will be needed to map Pal distal fragments to candidate gene promoters; a contacted fragment alone is not a target gene.

Recommended scope for eventual paper: perturbation-grounded **validation and calibration** of cell-context HAR–gene links, rather than claiming novel human-specific causal maturation programs from name matches.
