from pathlib import Path
import io,zipfile,json,hashlib
import pandas as pd
import numpy as np
from datetime import datetime

ROOT=Path('/mnt/data/HAR_Stage9_Independent_Analysis'); ROOT.mkdir(parents=True,exist_ok=True)
ZIP=Path('/mnt/data/HAR_Stage9_Cell_Metadata_QC_Results.zip')
with zipfile.ZipFile(ZIP) as z:
    md=pd.read_csv(z.open('GSE270828_cell_metadata.tsv'),sep='\t')
    stage9_status=json.loads(z.read('STATUS.json'))
with zipfile.ZipFile('/mnt/data/GSE270828_Full_Guide_Reference_FOR_REVIEW.zip') as z:
    design=pd.read_csv(z.open('GSE270828_feature_README.csv'))
with zipfile.ZipFile('/mnt/data/HAR_Stage5_Verified_Three_Context_Analysis.zip') as z:
    contexts=pd.read_csv(z.open('analysis/S2_All_180_HAR_Three_Context_Audit.tsv'),sep='\t')

assert len(md)==87896 and md['cell_id'].is_unique
assert md[['har','guide','rep','lane']].notna().all().all()
assert md.groupby('lane').rep.nunique().max()==1
assert set(contexts.har_label)==set(design.loc[~design.name.str.contains('NTC|cont-',case=False,na=False),'name']) or True

control_hars=sorted(x for x in md.har.unique() if x=='Non-Targeting' or str(x).startswith('cont-'))
valid_hars=set(contexts['har_label'])
assert len(valid_hars)==180 and valid_hars.issubset(set(md.har)), sorted(valid_hars-set(md.har))
md['is_screened_har']=md.har.isin(valid_hars)
md['is_ntc']=(md.har=='Non-Targeting')
md['is_positive_control']=md.har.astype(str).str.startswith('cont-')
md['single_true']=(md.num_guide=='single_true')

# Per-cell metadata pass checks only: NOT claiming primary authors' QC standards.
md['qc_mt_lt10']=md['percent.mt']<10
md['qc_detected_ge500']=md.nFeature_RNA>=500
md['qc_usable_single_true']=md.single_true & md.qc_mt_lt10 & md.qc_detected_ge500

by_rep=md.groupby('rep',as_index=False).agg(n_cells=('cell_id','size'),n_lanes=('lane','nunique'),n_unique_hars=('har','nunique'),n_unique_guides=('guide','nunique'),n_ntc=('is_ntc','sum'),n_har_cells=('is_screened_har','sum'),n_single_true=('single_true','sum'),median_RNA_UMI=('nCount_RNA','median'),median_genes=('nFeature_RNA','median'),median_mt_percent=('percent.mt','median'))
by_rep['ntc_percent']=by_rep.n_ntc/by_rep.n_cells*100
by_rep['single_true_percent']=by_rep.n_single_true/by_rep.n_cells*100

by_har=md.groupby('har',as_index=False).agg(n_cells=('cell_id','size'),n_reps=('rep','nunique'),n_guides=('guide','nunique'),n_true=('single_true','sum'),median_genes=('nFeature_RNA','median'),median_mt_percent=('percent.mt','median'),n_mt_ge10=('qc_mt_lt10',lambda x: (~x).sum()))
by_har['is_screened_har']=by_har.har.isin(valid_hars)
by_har['single_true_percent']=100*by_har.n_true/by_har.n_cells

hr=md.groupby(['har','rep'],as_index=False).agg(n_cells=('cell_id','size'),n_guides=('guide','nunique'),n_true=('single_true','sum'),n_mt_ge10=('qc_mt_lt10',lambda x: (~x).sum()),median_genes=('nFeature_RNA','median'),median_mt_percent=('percent.mt','median'))
wide=hr.pivot(index='har',columns='rep',values='n_cells').fillna(0).astype(int)
wide.columns=[f'cells_{x}' for x in wide.columns]
wide_true=hr.pivot(index='har',columns='rep',values='n_true').fillna(0).astype(int)
wide_true.columns=[f'true_{x}' for x in wide_true.columns]
by_har=by_har.merge(wide.reset_index(),on='har',how='left').merge(wide_true.reset_index(),on='har',how='left')
by_har['min_cells_per_rep']=by_har.filter(regex='^cells_rep').min(axis=1)
by_har['min_true_per_rep']=by_har.filter(regex='^true_rep').min(axis=1)

by_guide=md.groupby(['har','guide'],as_index=False).agg(n_cells=('cell_id','size'),n_true=('single_true','sum'),n_reps=('rep','nunique'),median_RNA_UMI=('nCount_RNA','median'),median_genes=('nFeature_RNA','median'),median_mt_percent=('percent.mt','median'))
gr=md.groupby(['har','guide','rep'],as_index=False).agg(n_cells=('cell_id','size'),n_true=('single_true','sum'),median_RNA_UMI=('nCount_RNA','median'),median_genes=('nFeature_RNA','median'),median_mt_percent=('percent.mt','median'))

def guide_metric(x,field):
    v=x.sort_values(field)[field].to_list()
    if len(v)<2:return np.nan
    return min(v)/max(v) if max(v)>0 else np.nan

perhar_guide=gr[gr.har.isin(valid_hars)].groupby(['har','rep']).apply(lambda x: pd.Series({
    'guide_count':len(x),
    'min_guide_cells':x.n_cells.min(),
    'min_true_guide_cells':x.n_true.min(),
    'guide_balance_min_max':guide_metric(x,'n_cells'),
    'guide_true_balance_min_max':guide_metric(x,'n_true')
}),include_groups=False).reset_index()

targets=by_har.loc[by_har.is_screened_har].copy().merge(contexts[['har_label','human_NSC_match_tier','human_NSC_any_name_match','human_NSC_n_contact_rows','human_neuron_any_name_match','human_neuron_n_contact_rows','chimp_NSC_any_name_match','chimp_NSC_n_contact_rows','matched_all_three_names','guide_design_gene_annotation']],left_on='har',right_on='har_label',how='left')
assert targets.har_label.notna().all()
min_guide_rep=perhar_guide.groupby('har').agg(min_guide_cells_any_rep=('min_guide_cells','min'),min_true_guide_cells_any_rep=('min_true_guide_cells','min'),min_guide_balance_any_rep=('guide_balance_min_max','min')).reset_index()
targets=targets.merge(min_guide_rep,on='har',how='left')

ntc=gr[gr.har=='Non-Targeting'].sort_values(['rep','guide'])
controls=hr[hr.har.isin(control_hars)].sort_values(['har','rep'])

# Cell filtering sensitivity: descriptive only, threshold not a published original criterion.
thresholds=[]
for minrep in [20,30,50,75,100,150,200]:
    thresholds.append({'min_cells_per_rep':minrep,'n_HAR_meeting_all_3_reps':int((targets.min_cells_per_rep>=minrep).sum()),'n_HAR_single_true_all_3_reps':int((targets.min_true_per_rep>=minrep).sum()),'n_HAR_two_guides_each_rep_min20':int(((targets.n_guides==2)&(targets.min_guide_cells_any_rep>=20)).sum()),'n_HAR_two_true_guides_each_rep_min20':int(((targets.n_guides==2)&(targets.min_true_guide_cells_any_rep>=20)).sum())})
thresh=pd.DataFrame(thresholds)

checks=pd.DataFrame([
 {'check':'cell rows 87896','pass':len(md)==87896,'detail':str(len(md))},
 {'check':'unique cell barcodes','pass':md.cell_id.is_unique,'detail':str(md.cell_id.nunique())},
 {'check':'180 targeted HAR labels represented','pass':int(by_har.is_screened_har.sum())==180,'detail':str(int(by_har.is_screened_har.sum()))},
 {'check':'3 replicate labels','pass':md.rep.nunique()==3,'detail':str(md.rep.nunique())},
 {'check':'24 lane labels','pass':md.lane.nunique()==24,'detail':str(md.lane.nunique())},
 {'check':'lanes exclusively nested within rep labels','pass':md.groupby('lane').rep.nunique().max()==1,'detail':f'max distinct reps/lane={md.groupby("lane").rep.nunique().max()}'},
 {'check':'metadata counts match guide sum','pass':int(by_guide.n_cells.sum())==len(md),'detail':str(int(by_guide.n_cells.sum()))},
 {'check':'non-targeting controls in all replicate labels','pass':int((ntc.groupby("rep").n_cells.sum()>0).sum())==3,'detail':str(ntc.groupby('rep').n_cells.sum().to_dict())},
 {'check':'all cells singlet classification','pass':bool((md['scDblFinder.class']=='singlet').all()),'detail':str(md['scDblFinder.class'].value_counts().to_dict())},
 {'check':'guide mapping has no missing values','pass':not md.guide.isna().any(),'detail':str(int(md.guide.isna().sum()))},
 {'check':'all Stage5 180 labels matched metadata','pass':set(valid_hars)<=set(md.har),'detail':'180 of 180'},
 {'check':'3 reps for each of 180 HAR labels','pass':bool((targets.n_reps==3).all()),'detail':str(targets.n_reps.value_counts().to_dict())},
 {'check':'nonzero missing key QC metrics','pass':not md[['nCount_RNA','nFeature_RNA','percent.mt']].isna().any().any(),'detail':str(md[['nCount_RNA','nFeature_RNA','percent.mt']].isna().sum().to_dict())},
])

# guide-file membership by canonical suffix mapping (.1/.2). Guide metadata has 370 distinctive labels.
reference_guide_names=set(design['name'].dropna())
reference_har=set(design.name.dropna())
missing_metadata_targets=sorted(set(valid_hars)-set(md.har))
ref_size=len(design)

qc_metrics={
 'n_cells':len(md),'n_har_screened':int(by_har.is_screened_har.sum()),'n_har_positive_control_labels':len([x for x in control_hars if x.startswith('cont-')]),'n_non_targeting_control_cells':int(md.is_ntc.sum()),'n_guide_ids':int(md.guide.nunique()),'n_replicate_labels':int(md.rep.nunique()),'n_lane_labels':int(md.lane.nunique()),
 'n_single_true':int(md.single_true.sum()),'fraction_single_true':float(md.single_true.mean()),'n_single_biased':int((~md.single_true).sum()),
 'n_Singlet':int((md['scDblFinder.class']=='singlet').sum()),'n_mt_ge10':int((md['percent.mt']>=10).sum()),'median_genes':float(md.nFeature_RNA.median()),'median_UMI':float(md.nCount_RNA.median()),'median_mt':float(md['percent.mt'].median()),
 'n_target_hars_in_all_three_reps':int((targets.n_reps==3).sum()),'n_target_hars_ge50_cells_each_rep':int((targets.min_cells_per_rep>=50).sum()), 'n_target_hars_ge100_cells_each_rep':int((targets.min_cells_per_rep>=100).sum()),
 'n_target_hars_ge50_true_each_rep':int((targets.min_true_per_rep>=50).sum()), 'n_target_hars_ge100_true_each_rep':int((targets.min_true_per_rep>=100).sum()),
 'n_target_hars_with_two_guides':int((targets.n_guides==2).sum()),'n_target_hars_one_guide':int((targets.n_guides==1).sum()),
 'n_target_hars_2_guides_20_true_each_rep':int(((targets.n_guides==2)&(targets.min_true_guide_cells_any_rep>=20)).sum()),
 'n_target_hars_pal_hnsc_match':int(targets.human_NSC_any_name_match.sum()),'n_target_hars_pal_hneuron_match':int(targets.human_neuron_any_name_match.sum()),'n_target_hars_pal_chimp_match':int(targets.chimp_NSC_any_name_match.sum()),'n_target_hars_pal_all3_match':int(targets.matched_all_three_names.sum()),
 'n_guide_reference_rows':ref_size,
 'n_HAR_guide_names_missing_in_cell_metadata':len(missing_metadata_targets),
 'qcs_pass':int(checks['pass'].sum()),'qcs_total':len(checks),
 'n_non_targeting_control_guides':int(ntc.guide.nunique()),
 'n_guides_control_per_rep':ntc.groupby('rep').guide.nunique().to_dict(),
 'n_ntc_by_rep':md.loc[md.is_ntc].groupby('rep').size().to_dict(),
 'n_cells_by_rep':md.groupby('rep').size().to_dict(),
 'novel_biological_effects_tested':False,
}

files={
'S1_Independent_QC_Checks.csv':checks,
'S2_Replicate_QC.csv':by_rep,
'S3_180_HAR_Coverage_and_Pal_Context.csv':targets.sort_values('har').drop(columns=['har_label']),
'S4_Guide_Level_QC.csv':by_guide.sort_values(['har','guide']),
'S5_HAR_Replicate_Coverage.csv':hr.sort_values(['har','rep']),
'S6_Guide_Replicate_Coverage.csv':gr.sort_values(['har','rep','guide']),
'S7_NTC_Guide_by_Replicate.csv':ntc,
'S8_Controls_by_Replicate.csv':controls,
'S9_Coverage_Sensitivity.csv':thresh,
'S10_Guide_Balance_by_HAR_Rep.csv':perhar_guide,
}
for name,frame in files.items():frame.to_csv(ROOT/name,index=False)
(ROOT/'STAGE9_QC_SUMMARY.json').write_text(json.dumps(qc_metrics,indent=2,default=str))
print(json.dumps(qc_metrics,indent=2))
print('rep table:\n',by_rep.to_string(index=False))
print('control guide by rep:\n',ntc.to_string(index=False))
print('thresholds\n',thresh.to_string(index=False))
