# GSE270828 Stage 9: independent metadata and guide/replicate QC

**Input**: original user-uploaded `HAR_Stage9_Cell_Metadata_QC_Results.zip`, including the full 87,896-row cell metadata TSV and R deserialization logs. Cross-context HAR contact evidence comes from the previously processed Stage 5 archive. This report is based on *observed metadata*, **not** reprocessing the large raw expression matrix.

## Core verified results

- The original **2,312,020,968-byte** double-GZIP RDS file was successfully loaded in R as a Seurat object and its metadata were recovered: **87,896 uniquely barcoded cells**, **370 guide labels**, **180 screened HAR labels**, **5 positive-control region labels**, plus **Non-Targeting** as the sixth control category.
- Three experimental `rep` labels occur: rep1 = **28,995** cells; rep2 = **31,728**; rep3 = **27,173**. Every screened HAR has cells in all three replicates. The 24 lanes are nested within the three replicate labels (8 per replicate), not independent replications.
- **1,518 Non-Targeting cells**: rep1 = **523**; rep2 = **511**; rep3 = **484**. Each `rep` has all six NTC guides, but `NTC3` has just **35 cells overall**, including 8, 19, and 8 per `rep`. This control needs guide-level sensitivity analysis.
- **63,335** (`72.06%`) cells have metadata `num_guide=single_true`; **24,561** (`27.94%`) have `single_biased`. The biological meaning of the latter must follow original guide-assignment definitions; do not automatically call these multiplets or contamination.
- Exactly **179/180 HARs** have two observed guide labels; `HACNS255` has one. All 180 HARs pass the minimum **20 cells per replicate** on all assignments; 177 pass 50 and 139 pass 100. Among `single_true`, 172 HARs have at least 50 cells per replicate and 97 have at least 100. A more demanding sensitivity rule (both guides have >=20 `single_true` cells **in each** `rep`) is met by **145** HARs. These are *exploratory cell-coverage thresholds*, not original preregistered criteria.
- The cell metadata contain only `singlet` for the doublet-class column and all mitochondrial-percent values are below 10%; this is consistent with **previous filtering**, but cannot prove the original unfiltered dataset was free from doublets or QC failures.
- Replicate-level medians for detected genes are rep1 **5,894**, rep2 **5,691**, rep3 **5,227**; median mitochondrial percent is **2.75**, **3.70**, **3.76**. Therefore, technical or biological replicate effects must be handled explicitly before expression comparisons.
- Stage 5 bait-name coverage for these 180 HAR IDs: **174** matched in human neural stem cells, **169** in human neurons, **171** in chimp neural stem cells, **163** in all three. **These are identifier matches**, not validated gene targets or normalized cross-species contact effect sizes.

## Scientific limitations and statistical plan

1. `rep1`–`rep3` may represent experimental repeat/batch labels, but **independent biological donor identities have not been demonstrated**. Lanes and individual single cells must never be treated as independent donors.
2. Cell-assignment and QC summaries **cannot be converted into gene-expression differential effects or causal HAR–gene claims**. The 2.31-GB RDS contains expression data but that matrix is absent from the uploaded ZIP.
3. Stage 10 notebook will try to extract *verified raw RNA counts* aggregated at `rep × HAR` for `single_true` assignments, while retaining matched Non-Targeting controls. It stops if cell-barcode alignment, count-matrix identity, or integer counts cannot be verified. No significance tests are run in Stage 10.
4. Once the raw-count aggregates are returned, guide-level concordance, batch-aware differential expression, RNA depth normalization, multiple-testing correction, and appropriate negative-control strategies must be designed and reported. With just three replicate labels, inference will remain limited and sensitivity analyses essential.

**Output inventory:** supplementary Excel workbook (8 sheets), ten detailed machine-readable CSV tables, two figures, the exact analysis Python script, Stage 10 no-Google-Drive Colab notebook, and this report. No novel biological targets, P-values, or experimentally measured maturation delays are claimed.
