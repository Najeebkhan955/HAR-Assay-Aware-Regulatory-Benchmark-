GSE270828 Stage 8: nested gzip diagnosis and cell-level metadata QC only. No differential expression performed. No Google Drive used. Original multi-GB file is not included.
