args <- commandArgs(trailingOnly=TRUE)
if (length(args) < 5) stop('Expected args: path, output_tsv, log, layers, format')
source_path <- args[[1]]
out_path <- args[[2]]
log_path <- args[[3]]
layers <- as.integer(args[[4]])
fmt <- args[[5]]

logline <- function(...) cat(format(Sys.time(),'%Y-%m-%d %H:%M:%S'),...,"\n",file=log_path,append=TRUE)
logline('START', 'gzip_layers',layers,'format',fmt)
if (layers < 1 || layers > 5) stop('Unexpected gzip layer depth')
if (!file.exists(source_path)) stop('Source missing')
# Execute gzip decompression through a pipe so no extra multi-GB data copy is written to disk.
# Source filename is fixed by the notebook and is safe to shell-quote.
quoted_path <- shQuote(source_path)
command <- paste(c(paste('gzip -dc', quoted_path), rep('gzip -dc', layers-1L)), collapse=' | ')
logline('Streaming command prepared; now reading original object into R memory')
con <- pipe(command, open='rb')
if (!isOpen(con)) stop('Could not open gzip streaming connection')
# Connection is closed after successful read; R process closes it on exceptions.

if (fmt=='RDS') {
  obj <- readRDS(con)
} else if (fmt=='R_workspace') {
  env <- new.env(parent=globalenv())
  n <- load(con, envir=env)
  logline('Workspace objects',paste(n,collapse=','))
  if (length(n)==0L)stop('Empty R workspace')
  scores <- vapply(n,function(name) {
      a <- get(name,envir=env)
      isS4(a) && 'meta.data' %in% slotNames(a) || (is.list(a) && !is.null(a$meta.data))
  },logical(1))
  idx <- if (any(scores)) which(scores)[[1]] else 1L
  obj <- get(n[[idx]],envir=env)
} else stop('Unexpected serialization format')
close(con)
logline('R object deserialized','class',paste(class(obj),collapse=';'))

md <- NULL
if (isS4(obj) && 'meta.data' %in% methods::slotNames(obj)) md <- methods::slot(obj,'meta.data')
if (is.null(md) && is.list(obj) && !is.null(obj$meta.data)) md <- obj$meta.data
if (is.null(md) && is.data.frame(obj)) md <- obj
if (is.null(md) && is.list(obj) && !is.null(obj$obs)) md <- obj$obs
if (is.null(md) || !is.data.frame(md)) stop('Serialized object loaded, but no accessible cell-level metadata data.frame was identified')
logline('Metadata rows',nrow(md),'columns',ncol(md))
want <- c('orig.ident','lane','rep','replicate','batch','guide','har',
          'perturbation_name','num_guide','nCount_RNA','nFeature_RNA',
          'percent.mt','scDblFinder.class','scDblFinder.score')
extra <- grep('rep|batch|lane|guide|crispr|mt|sample|donor|har|perturb',names(md),ignore.case=TRUE,value=TRUE)
keep <- unique(c(intersect(want,names(md)),extra))
if(length(keep)==0L)stop('Metadata found but none of the required experimental design columns available')
md <- md[,keep,drop=FALSE]
md$cell_id <- rownames(md)
md <- md[,c('cell_id',setdiff(names(md),'cell_id')),drop=FALSE]
for (n in names(md)) if(is.list(md[[n]])) md[[n]] <- vapply(md[[n]],function(x)paste(x,collapse=';'),character(1))
write.table(md,file=out_path,sep='\t',quote=TRUE,row.names=FALSE,na='')
logline('SUCCESS','saved',out_path)
