# Stage 2 audit results

This run documents source acquisition and data feasibility. It does not establish HAR-to-gene causality, evolutionary positive selection, or a neuronal maturation phenotype.

- Source acquisition: see 01_source_manifest.tsv, SHA256 hashes.
- GSM metadata: see 02_GEO_GSM_metadata.tsv; **no independent donor count inferred**.
- Contacts: see 03_Pal_contact_descriptive_summary.tsv, if originals were obtained.
- Genomic join: see 06_coordinate_overlap_status.json; blocked unless independently verified.
- Perturbation effects: see 07_effect_table_status.json; real effects not inferred from guide metadata.
- All findings are provisional pending biological replication and provenance review.
