from pathlib import Path
import zipfile,io,json,hashlib
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

SRC=Path('/mnt/data/HAR_Stage2_Run_Outputs.zip')
OUT=Path('/mnt/data/HAR_Stage2_Analysis_Verified')
OUT.mkdir(exist_ok=True)
with zipfile.ZipFile(SRC) as z:
    def tsv(name): return pd.read_csv(io.BytesIO(z.read('results/'+name)),sep='\t')
    r=tsv('04_GSE292632_target_regions_as_supplied.tsv')
    md=tsv('02_GEO_GSM_metadata.tsv')
    manifest=tsv('01_source_manifest.tsv')
    audit=json.loads(z.read('results/10_FINAL_AUDIT.json'))
    assert z.testzip() is None
    m={'original_zip_filename':SRC.name,'original_zip_sha256':hashlib.sha256(SRC.read_bytes()).hexdigest(),'members':{a.filename:{'bytes':a.file_size,'sha256':hashlib.sha256(z.read(a.filename)).hexdigest()} for a in z.infolist()}}

assert len(r)==106 and r.region_id.is_unique
assert not r.isna().any().any()
assert ((r.start>=0)&(r.end>r.start)).all()
assert len(md)==86 and md.gsm.is_unique
r['length_bp']=r['end']-r['start']
r.to_csv(OUT/'S1_106_Region_Inventory.tsv',sep='\t',index=False)
md.to_csv(OUT/'S2_86_GSM_Metadata.tsv',sep='\t',index=False)
manifest.to_csv(OUT/'S3_Original_Source_Manifest.tsv',sep='\t',index=False)
(OUT/'S4_Input_Archive_SHA256.json').write_text(json.dumps(m,indent=2))

def group_type(d):
    if d['gse']=='GSE270828':
        import re
        a=re.search(r'Batch\s+(\d+)',d['title'],flags=re.I)
        b=re.search(r'Lane\s+(\d+)',d['title'],flags=re.I)
        library='CRISPR capture' if 'CRISPR-Capture' in d['title'] else ('Gene expression' if 'Gene Expression' in d['title'] else 'OTHER')
        return f"Batch {a.group(1) if a else 'unknown'} / {library}",f"Lane {b.group(1) if b else 'unknown'}"
    if d['gse']=='GSE292632':
        spp='chimpanzee' if 'chimpanzee' in d['title'].lower() else ('human' if 'human' in d['title'].lower() else 'unknown')
        ass='guide capture' if 'gRNA library' in d['title'] else ('gene expression' if 'gene expression library' in d['title'] else 'OTHER')
        return f'{spp} / {ass}','technical library or reaction, not donor'
    return 'Macaque PFC / snRNA-seq','age series, not independent donor count'
rows=[]
for _,d in md.iterrows():
    grp,unit=group_type(d)
    rows.append({'gse':d['gse'],'gsm':d['gsm'],'audit_class':grp,'unit_warning':unit})
met=pd.DataFrame(rows)
met.to_csv(OUT/'S5_Metadata_Unit_Audit.tsv',sep='\t',index=False)
chrom=r.groupby('chrom',as_index=False).agg(regions=('region_id','nunique'),total_bp=('length_bp','sum'),median_length_bp=('length_bp','median'))
chrom.to_csv(OUT/'S6_Chromosomal_Region_Distribution.tsv',sep='\t',index=False)

fig,ax=plt.subplots(figsize=(11,4.8))
chrom2=chrom.copy()
chrom2['sort']=chrom2.chrom.apply(lambda v: int(v) if str(v).isdigit() else 99)
chrom2=chrom2.sort_values('sort')
ax.bar(chrom2.chrom,chrom2.regions,edgecolor='black',linewidth=0.25)
ax.set_xlabel('Chromosome (as supplied in original BED)')
ax.set_ylabel('Number of screened regions')
ax.set_title('GSE292632: 106 screened regulatory regions — descriptive coverage only')
ax.spines[['top','right']].set_visible(False)
ax.set_axisbelow(True);ax.grid(axis='y',alpha=.2)
fig.tight_layout()
fig.savefig(OUT/'F1_GSE292632_Region_Chromosome_Coverage.png',dpi=220,facecolor='white')
plt.close(fig)

summary={
  'generated_from_user_uploaded_zip':SRC.name,
  'archive_integrity':True,
  'downloaded_source_count':int((manifest.status=='downloaded').sum()),
  'missing_source_count':int((manifest.status!='downloaded').sum()),
  'GEO_GSM_total':int(len(md)),
  'GEO_GSM_per_series':{k:int(v) for k,v in md.gse.value_counts().sort_index().items()},
  'GSE292632_region_count':int(len(r)),
  'GSE292632_interval_checks':{'no_duplicates':bool(r.region_id.is_unique),'all_positive_lengths':bool((r.length_bp>0).all()),'zero_negative_starts':bool((r.start>=0).all())},
  'GSE292632_covered_chromosomes':int(r.chrom.nunique()),
  'GSE292632_median_region_length_bp':float(r.length_bp.median()),
  'GSE270828_biological_donors':'NOT DETERMINED; lanes not donors',
  'GSE292632_biological_donors':'NOT DETERMINED; technical reactions are not donors',
  'GSE305245_human_samples_in_uploaded_metadata':0,
  'Pal_interactions':'MISSING (Dryad HTTP 403 reported in Colab)',
  'coordinate_overlap':'BLOCKED; original Pal table and verified genomic build / interval semantics required',
  'perturbation_gene_effects':'NOT AVAILABLE IN ZIP',
  'HAR_gene_positives':'NOT ESTIMATED',
  'model_benchmark':'NOT RUN',
  'original_source_files_in_output_zip':False,
  'no_significance_inference':'No false negative or p-values inferred from unavailable source data'
}
(OUT/'VERIFIED_STAGE2_RESULTS.json').write_text(json.dumps(summary,indent=2))
text=f'''# Stage 2 — Independent audit of the uploaded Colab output

**Input:** `{SRC.name}`  
**Archive SHA256:** `{m['original_zip_sha256']}`  
**Status:** Files audited; no novel HAR–gene or maturation findings claimed.

## Confirmed results

- Archive is readable; {len(m['members'])} files, all hashes recorded.
- {summary['downloaded_source_count']}/10 source downloads succeeded; four Dryad files reported HTTP 403 errors.
- {len(r)} distinct intervals are valid (zero duplicate IDs, zero zero/negative-length intervals). Median length {r.length_bp.median():.0f} bp, {r.chrom.nunique()} chromosomes represented.
- {len(md)} GSM records parsed: {', '.join(f'{s}: {n}' for s,n in md.gse.value_counts().sort_index().items())}.
- GSE270828's 48 records represent sequencing lanes and assay libraries, **not 48 biological lines**.
- GSE292632's 16 records represent reactions/libraries from human and chimpanzee NPC lines, **not 16 donors**.
- 22 GSE305245 records in this archive are labeled macaque. Do **not** infer a human sample was processed.

## Analyses not legitimately available

1. Pal hNSC/cNSC/neuron interaction files were not downloaded; no contacts or overlap counts were computed.
2. The 106 regions belong to a CRISPRi screen of cis-regulated open chromatin regions; they are **not established HAR coordinates**.
3. The region BED genome build/coordinate convention was not independently verified against the Pal datasets; `hg38` in region IDs is insufficient.
4. This ZIP contains 5-row guide previews, not the full 40.9KB GSE270828 guide reference, and has **no** differential-expression effect results, normalized gene counts, or tested negative controls.
5. No positive target benchmark, ranking improvement, selection test or developmental delay can be reported.

## Next smallest user action

Download `HAR_interactions_hNSCs.txt` (2.64 MB) from the official Dryad page, then upload the original file into this same chat. It can be checked here without restarting Colab. If downloading that single file is blocked in your browser, use the official 'Download full dataset' action and upload the resulting archive instead.

Official dataset: https://datadryad.org/dataset/doi:10.5061/dryad.c59zw3rkj

Note: hNSC chromatin contacts support descriptive target hypotheses, not perturbation-validated gene links. A follow-up action will be to export the original GEO source files and acquire HAR–gene differential-expression tables in order to benchmark prediction models.
'''
(OUT/'READ_ME_FIRST.md').write_text(text)
(OUT/'NEXT_STEP_ROMAN_URDU.txt').write_text('''Bhai, ab Colab phir run karne ki zaroorat nahi.\n\n1) Is link ko browser mein open karein: https://datadryad.org/dataset/doi:10.5061/dryad.c59zw3rkj\n2) Data files mein `HAR_interactions_hNSCs.txt` par click karein (approx. 2.64 MB).\n3) Download hone wali ORIGINAL .txt file ko isi ChatGPT conversation mein upload kar dein.\n4) Agar file par 403 aaye to "Download full dataset" try karein aur full ZIP share kar dein.\n5) Main file ki genomic-coordinate QC, candidate-region evidence aur valid comparison khud karunga.\n\nDo not rename or modify the raw file.\n''')
print(json.dumps(summary,indent=2))
