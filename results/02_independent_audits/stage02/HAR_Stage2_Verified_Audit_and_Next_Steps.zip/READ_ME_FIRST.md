# Stage 2 — Independent audit of the uploaded Colab output

**Input:** `HAR_Stage2_Run_Outputs.zip`  
**Archive SHA256:** `d77950118bc8090601bfff04b272ae5e4b2915b2730a4b96f4ff3d805f425f0c`  
**Status:** Files audited; no novel HAR–gene or maturation findings claimed.

## Confirmed results

- Archive is readable; 12 files, all hashes recorded.
- 6/10 source downloads succeeded; four Dryad files reported HTTP 403 errors.
- 106 distinct intervals are valid (zero duplicate IDs, zero zero/negative-length intervals). Median length 635 bp, 22 chromosomes represented.
- 86 GSM records parsed: GSE270828: 48, GSE292632: 16, GSE305245: 22.
- GSE270828's 48 records represent sequencing lanes and assay libraries, **not 48 biological lines**.
- GSE292632's 16 records represent reactions/libraries from human and chimpanzee NPC lines, **not 16 donors**.
- 22 GSE305245 records in this archive are labeled macaque. Do **not** infer a human sample was processed.

## Analyses not legitimately available

1. Pal hNSC/cNSC/neuron interaction files were not downloaded; no contacts or overlap counts were computed.
2. The 106 regions belong to a CRISPRi screen of cis-regulated open chromatin regions; they are **not established HAR coordinates**.
3. The region BED genome build/coordinate convention was not independently verified against the Pal datasets; `hg38` in region IDs is insufficient.
4. This ZIP contains 5-row guide previews, not the full 40.9KB GSE270828 guide reference, and has **no** differential-expression effect results, normalized gene counts, or tested negative controls.
5. No positive target benchmark, ranking improvement, selection test or developmental delay can be reported.

## Next smallest user action

Download `HAR_interactions_hNSCs.txt` (2.64 MB) from the official Dryad page, then upload the original file into this same chat. It can be checked here without restarting Colab. If downloading that single file is blocked in your browser, use the official 'Download full dataset' action and upload the resulting archive instead.

Official dataset: https://datadryad.org/dataset/doi:10.5061/dryad.c59zw3rkj

Note: hNSC chromatin contacts support descriptive target hypotheses, not perturbation-validated gene links. A follow-up action will be to export the original GEO source files and acquire HAR–gene differential-expression tables in order to benchmark prediction models.
