# Stage 4 – Verified guide-design / chromatin-bait ID analysis

## Data provenance
- GSE270828 original `GSE270828_feature_README.csv`: SHA256 `a56978bcfc4f9b5a80a5f1c62ffcd589525a973f695be52c48eac13704889a2b`.
- Pal et al. original `HAR_interactions_hNSCs.txt`: SHA256 `ea2d53af9cf2ace7a563a28dc62ff70c3ab14fc694bc599ab6a201c669be7efa`.
- Cross-study matching is a **HAR label-matching exercise**, not a perturbation-effect analysis or physical CRISPR guide-to-bait coordinate overlap test.

## Independent numeric audit
- GSE270828: **370** guide records; **359** targeting guides for **180** distinct HAR labels; **6 non-targeting and 5 named control guides**. **164** distinct design-gene annotations among the 180 screened HARs. Most HARs have 2 distinct guides (179/180), one has 1.
- Pal hNSC contact table: **39,093** source rows. Source includes HAR and HGE-labelled fragments.
- Unique HAR label matches: **109 exact bait-name**, **63 additional comma-separated composite bait names**, **2 additional `_sec`/`_tert` flanking labels**, and **6 absent**. In total **174/180 = 96.7%** show some name-level match. For a strict exact label only, the rate is **109/180 = 60.6%**. For core-name token matching excluding flank-only, **172/180 = 95.6%**.
- A total of **3,331 distinct Pal source interaction rows** carry at least one screened HAR label, after matching composite names and flanking suffixes. Since composite rows may carry multiple HARs, per-HAR counts should **not be added** as independent contacts.
- No perturbation response statistics, guide efficiency, gene expression effect, gene promoter annotations, or original HAR interval coordinates are provided by this CSV. `target_gene_name` is the **design annotation**, not experimentally validated causal target.

## Six unmatched HAR labels
2xHAR.49, HACNS105, HACNS255, HACNS278, HACNS325, HACNS805.

## Gene-annotation caution illustrated by HAR181
In the original `GSE270828_feature_README.csv`, the two `HAR181` guides carry `target_gene_name=NXPE2` (design annotation), whereas the published Noble et al. 2024 screen paper reports experimental follow-up involving HAR181 and **CADM1** (https://pmc.ncbi.nlm.nih.gov/articles/PMC11244942/). This is a concrete reason **not** to interpret `target_gene_name` as a validated functional gene target or to equate design proximity with experimentally supported regulation. This does not mean the original annotations are erroneous: they answer different questions.

## Stage 3 distinction
The prior GSE292632 test of 106 distinct candidate regulatory intervals found 5 overlaps at Pal *OtherEnd* fragments (9 rows) and no bait-coordinate overlaps. The **9 source bait names in those rows do not overlap any of the 180 GSE270828 guide-screen HAR names**. The previous 5/106 and the new 174/180 quantify different evidence types and must never be combined into an experimental replication claim.

## Critical limitations
1. **Names** match, not yet physical guide-target intervals; the guide CSV lacks genomic target coordinates.
2. CHiCAGO contact scores refer to chromatin interactions, **not** expression-effect magnitudes, causal probabilities, or gene targets.
3. Flanking `_sec`/`_tert` names are lower-confidence correspondence, not proof that the central HAR element coincides with each captured fragment.
4. No cross-species comparative significance can be inferred from a single hNSC contact table.
5. False negatives cannot be inferred from missing identifiers or non-significant assays without power/coverage assessment.

## Proposed next verification
Acquire additional Dryad human-neuron and chimpanzee-NSC Capture-HiC contact tables (each <2MB) to test **label-level coverage differences**, with caution about unequal capture sensitivity. Then obtain actual GSE270828 per-guide or per-HAR gene expression *effect estimates* or an appropriate processed object, ideally authors' supplementary results, to benchmark regulatory predictions. GSE270828's ~2.2 GB RDS.gz count matrix would require a high-memory run and is not requested yet.
