# HAR project — Stage 4 handover

## What has been independently computed
Guide-design QC, name-matching of 180 GSE270828 HARs against Pal human neural-stem-cell bait-fragment labels, and descriptive inspection of associated Capture-HiC contact records. Exact, comma-separated composite, and flanking-fragment-only identifiers are kept separate. Inputs have no perturbation-effect estimates.

## Directory
- `S0` numerical audit in JSON
- `S1` all 370 guides (including controls)
- `S2` 180 HAR per-name match with designed gene annotation clearly marked
- `S3` all matching contact entries with Pal original source line references
- `S4` 164 distinct designed gene annotations (not response targets)
- `S5` six absent bait identifiers
- `S6` cross-check of Stage3 GSE292632 other-end intersections
- `S7` input/source statistics
- `S8` illustrative HAR181 design annotation vs cited functional result
- `F1` and `F2` high-resolution data-derived figures (PNG+PDF)
- `HAR_Stage4_Supplementary_Analysis.xlsx` searchable multi-sheet workbook
- `REPORT_Stage4_Scientific_Interpretation.md` full scientifically conservative interpretation
- `NEXT_ACTION_ROMAN_URDU.md` the user's next step
- `ORIGINAL_INPUTS/` frozen source files for reproducible independent rerun
- `REPRODUCE_STAGE4_ANALYSIS.py` executable original audit code

## Reproduce

Install Python 3.10+ with `pandas numpy matplotlib`. In the extracted ZIP root run:

```bash
python REPRODUCE_STAGE4_ANALYSIS.py --guide-zip ORIGINAL_INPUTS/GSE270828_Full_Guide_Reference_FOR_REVIEW.zip --pal ORIGINAL_INPUTS/HAR_interactions_hNSCs.txt --stage3 ORIGINAL_INPUTS/Stage3_Previous_9_Contacts.tsv --out REPRODUCED
```

Outputs are descriptive, not validation of the HAR-to-gene causal effect. This package does not include experimentally measured perturbation response contrasts.

## Primary sources
GSE270828 https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270828
Pal Dryad https://doi.org/10.5061/dryad.c59zw3rkj
Noble study https://pmc.ncbi.nlm.nih.gov/articles/PMC11244942/
