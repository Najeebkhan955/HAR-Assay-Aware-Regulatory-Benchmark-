#!/usr/bin/env python3
"""Reproduce Stage 4 name-based GSE270828 guide x Pal hNSC Capture-HiC audit.

Inputs are user-supplied original data. No functional perturbation effects are
included in this analysis. Chromatin-contact rows are NOT target-gene results.
"""
import argparse
import hashlib
import io
import json
import re
import zipfile
from collections import defaultdict, Counter
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

GUIDE_FILE = 'GSE270828_feature_README.csv'
EXPECTED_COLS = ['id','name','read','pattern','sequence','feature_type','target_gene_id','target_gene_name']
PAL_COLS = ['Bait_chr','Bait_start','Bait_end','Bait_name','OtherEnd_chr','OtherEnd_start','OtherEnd_end','CHiCAGO_score']
RE_SUFFIX = re.compile(r'(_sec|_tert)$')


def sha256(data): return hashlib.sha256(data).hexdigest()
def control_type(name):
    if name.startswith('NTC'): return 'non-targeting control'
    if name.startswith('cont_'): return 'named positive/control guide'
    return 'HAR-screen guide'

def parse_token(s):
    s = s.strip()
    base = RE_SUFFIX.sub('', s)
    return base, ('flanking fragment' if base != s else 'core fragment')

def run(guide_zip, pal_path, outdir, stage3_path=None):
    outdir=Path(outdir); outdir.mkdir(parents=True,exist_ok=True)
    raw_pal=Path(pal_path).read_bytes()
    pal=pd.read_csv(io.BytesIO(raw_pal),sep='\t')
    assert pal.columns.tolist() == PAL_COLS
    with zipfile.ZipFile(guide_zip) as z:
        raw_guide=z.read(GUIDE_FILE)
        reported=json.loads(z.read('GSE270828_guide_reference_summary.json'))
    assert sha256(raw_guide)==reported['sha256'], 'Input guide SHA256 mismatch'
    guides=pd.read_csv(io.BytesIO(raw_guide))
    assert guides.columns.tolist()==EXPECTED_COLS
    for c in ['Bait_start','Bait_end','OtherEnd_start','OtherEnd_end']:
        assert pd.api.types.is_integer_dtype(pal[c])
    assert bool((pal.Bait_start<pal.Bait_end).all()) and bool((pal.OtherEnd_start<pal.OtherEnd_end).all())
    assert bool((pal.Bait_chr==pal.OtherEnd_chr).all())
    assert not pal.isna().any().any() and not guides.isna().any().any()
    assert guides.id.is_unique and guides.sequence.is_unique
    assert len(guides)==370
    guides['guide_group']=guides.name.map(control_type)
    targets=guides[guides.guide_group.eq('HAR-screen guide')].copy()
    assert targets.name.nunique()==180 and len(targets)==359
    assert targets.groupby('name').target_gene_name.nunique().eq(1).all()
    # Tokenization splits comma-separated HAR identifiers and retains the Pal
    # secondary/tertiary bait-fragment suffixes as context, not core equivalence.
    # There can be multiple independent fragments carrying the same HAR label.
    per_har_records=defaultdict(list)
    for row in pal.itertuples(index=True):
        i=row.Index
        label=row.Bait_name
        for token in label.split(','):
            base,fragment_type=parse_token(token)
            if base in set(targets.name):
                if fragment_type=='flanking fragment':
                    basis='flank_suffix_only'
                elif label == base:
                    basis='exact_bait_label'
                else:
                    basis='composite_bait_label'
                per_har_records[base].append({
                    'har_label':base,
                    'pal_source_data_row_number':int(i+2),
                    'guide_design_gene_annotation':targets.loc[targets.name.eq(base),'target_gene_name'].iat[0],
                    'matched_component':token,
                    'match_basis':basis,
                    'Bait_chr':row.Bait_chr,'Bait_start':int(row.Bait_start),'Bait_end':int(row.Bait_end),
                    'Bait_name_original':row.Bait_name,
                    'OtherEnd_chr':row.OtherEnd_chr,'OtherEnd_start':int(row.OtherEnd_start),
                    'OtherEnd_end':int(row.OtherEnd_end), 'CHiCAGO_score':float(row.CHiCAGO_score),
                    'functional_perturbation_evidence_in_this_table':False,
                    'gene_mapping_validation_in_this_table':False,
                })
    assert len(per_har_records)==174
    # Create full per-guide and per-HAR audit
    guides.insert(0,'original_guide_row_number',np.arange(2,len(guides)+2))
    guides['guide_length_bp']=guides.sequence.str.len()
    guides['design_annotation_not_perturbation_result']=True
    guides.to_csv(outdir/'S1_All_370_Guides_With_Controls.tsv',sep='\t',index=False)
    rows=[]
    for name,grp in targets.groupby('name',sort=True):
        edges=pd.DataFrame(per_har_records[name]); kinds=set(edges.match_basis) if not edges.empty else set()
        if 'exact_bait_label' in kinds:category='exact bait-name'
        elif 'composite_bait_label' in kinds:category='composite bait-name'
        elif 'flank_suffix_only' in kinds:category='flanking fragment only'
        else:category='not identified'
        rows.append({
            'har_name':name,'n_guides':len(grp),'n_distinct_guide_sequences':grp.sequence.nunique(),
            'design_target_gene_id':grp.target_gene_id.iloc[0],
            'design_target_gene_name':grp.target_gene_name.iloc[0],
            'match_tier':category,
            'matched_to_pal_name':not edges.empty,
            'n_contact_rows_with_har_label':len(edges),
            'n_distinct_pal_bait_fragments':edges[['Bait_chr','Bait_start','Bait_end','Bait_name_original']].drop_duplicates().shape[0] if not edges.empty else 0,
            'n_core_contact_rows':int(edges.match_basis.isin(['exact_bait_label','composite_bait_label']).sum()) if not edges.empty else 0,
            'n_flanking_contact_rows':int(edges.match_basis.eq('flank_suffix_only').sum()) if not edges.empty else 0,
            'n_contacts_CHiCAGO_score_ge_5':int((edges.CHiCAGO_score>=5).sum()) if not edges.empty else 0,
            'max_CHiCAGO_score':round(float(edges.CHiCAGO_score.max()),3) if not edges.empty else np.nan,
            'median_CHiCAGO_score':round(float(edges.CHiCAGO_score.median()),3) if not edges.empty else np.nan,
            'is_bait_fragment_overlap_confirmed_with_original_CRISPRi_target_coordinates':False,
            'is_design_gene_a_validated_target_based_on_these_inputs':False,
        })
    overview=pd.DataFrame(rows)
    overview.to_csv(outdir/'S2_All_180_HAR_Name_Match_Audit.tsv',sep='\t',index=False)
    contacts=pd.DataFrame([r for edges in per_har_records.values() for r in edges]); contacts=contacts.sort_values(['har_label','pal_source_data_row_number']).reset_index(drop=True)
    contacts.to_csv(outdir/'S3_Annotated_Matched_Contact_Records.tsv',sep='\t',index=False)
    gene=overview.groupby(['design_target_gene_id','design_target_gene_name'],as_index=False).agg(
        n_screened_HAR_names=('har_name','nunique'),
        n_Pal_name_matched_HARs=('matched_to_pal_name','sum'),
        n_associated_contact_entries=('n_contact_rows_with_har_label','sum'),
        screened_HAR_labels=('har_name',lambda x:';'.join(x)),
    ).sort_values(['n_screened_HAR_names','design_target_gene_name'],ascending=[False,True]);gene['design_annotation_is_not_a_functional_target_result']=True
    gene.to_csv(outdir/'S4_164_Design_Gene_Annotations_Only.tsv',sep='\t',index=False)
    overview.loc[~overview.matched_to_pal_name].to_csv(outdir/'S5_Six_No_Matched_Bait_Identifiers.tsv',sep='\t',index=False)
    # One gene != one regulatory target. Distinct molecular pairs require
    # independent experimental effects and promoter annotation.
    mcounts=overview.match_tier.value_counts()
    expected={'exact bait-name':109,'composite bait-name':63,'flanking fragment only':2,'not identified':6}
    assert all(int(mcounts.get(k,0))==v for k,v in expected.items()), mcounts.to_dict()
    assert len(gene)==164
    # Document that previously observed GSE292632-OtherEnd overlaps do not
    # share the GSE270828 HAR bait labels, even after token normalisation.
    stage3_summary=[]
    if stage3_path and Path(stage3_path).exists():
        stage3=pd.read_csv(stage3_path,sep='\t')
        n=stage3['Bait_name'].apply(lambda x:len(set(targets.name)&set(parse_token(c)[0] for c in str(x).split(','))))
        stage3['number_of_GSE270828_screened_HAR_labels_at_this_bait']=n
        stage3['same_screen_HAR_identifier_evidence']=n.gt(0)
        stage3.to_csv(outdir/'S6_Prior_GSE292632_OtherEnd_Overlap_Not_Same_Target.tsv',sep='\t',index=False)
        stage3_summary=[{'previous_other_end_coincidences':len(stage3),'same_screen_bait_identifier_coincidences':int(n.gt(0).sum())}]

    # Original 39,093 contact rows may be shared by multiple names in a
    # composite bait label, so deduplicate source rows before reporting.
    unique_pal_contact_rows=int(contacts.pal_source_data_row_number.nunique())
    assert unique_pal_contact_rows==3331
    n_match=int(overview.matched_to_pal_name.sum())
    n_guides_matched=int(guides[guides.name.isin(overview.loc[overview.matched_to_pal_name,'har_name'])].shape[0])
    summary={
      'guide_source_sha256':sha256(raw_guide),'pal_hNSC_source_sha256':sha256(raw_pal),
      'GSE270828_total_guide_records':len(guides),
      'GSE270828_unique_labels_including_controls':int(guides.name.nunique()),
      'GSE270828_nontargeting_guide_records':int(guides.guide_group.eq('non-targeting control').sum()),
      'GSE270828_named_positive_control_guide_records':int(guides.guide_group.eq('named positive/control guide').sum()),
      'GSE270828_HAR_targeting_guide_records':len(targets),
      'GSE270828_screened_HAR_names':int(overview.shape[0]),
      'GSE270828_unique_guide_design_gene_annotations_for_HARs':int(gene.shape[0]),
      'Pal_hNSC_contact_rows':len(pal),
      'Pal_hNSC_contact_rows_with_one_or_more_screen_HAR_labels':unique_pal_contact_rows,
      'All_HAR_labels_exact_bait_name_only':int(mcounts.get('exact bait-name',0)),
      'All_HAR_labels_composite_name_not_separate_exact':int(mcounts.get('composite bait-name',0)),
      'All_HAR_labels_flanking_fragment_only':int(mcounts.get('flanking fragment only',0)),
      'All_HAR_labels_without_name_match':int(mcounts.get('not identified',0)),
      'All_HAR_labels_with_any_identifier_match':n_match,
      'GSE270828_guide_records_with_any_matched_HAR':n_guides_matched,
      'All_HAR_identifier_coverage_fraction':round(n_match/len(overview),6),
      'independent_gene_target_validation':False,
      'biological_perturbation_response_estimates_available':False,
      'original_HAR_crispri_target_coordinates_in_guide_reference':False,
      'meaning_of_164_genes':'design-stage gene annotations; not perturbation-validated regulator targets',
      'stage3_join':stage3_summary,
    }
    (outdir/'S0_Verified_Stage4_Summary.json').write_text(json.dumps(summary,indent=2),encoding='utf8')
    # Static publication-style plots with true computed counts.
    plt.rcParams.update({'font.size':11,'axes.spines.top':False,'axes.spines.right':False,'figure.facecolor':'white','axes.facecolor':'white'})
    fig,ax=plt.subplots(figsize=(9.3,4.8),dpi=160)
    cats=['Exact name','Composite name','Flanking only','No match']; vals=[109,63,2,6]
    bars=ax.barh(cats[::-1],vals[::-1],height=.62)
    ax.set_xlabel('GSE270828 screened HAR labels (n = 180)');ax.set_title('Cross-dataset identifier-matching evidence',pad=15,fontweight='bold')
    ax.set_xlim(0,128);ax.grid(axis='x',alpha=.16)
    for bar,value in zip(bars,vals[::-1]):ax.text(bar.get_width()+2,bar.get_y()+bar.get_height()/2,str(value),va='center')
    ax.text(.99,-.22,'Identifier matches only · not evidence of HAR–gene regulatory causality',transform=ax.transAxes,ha='right',color='.38',fontsize=9)
    fig.tight_layout();fig.savefig(outdir/'F1_GSE270828_to_Pal_Identifier_Match_Tiers.png',dpi=330,bbox_inches='tight',facecolor='white');fig.savefig(outdir/'F1_GSE270828_to_Pal_Identifier_Match_Tiers.pdf',bbox_inches='tight',facecolor='white');plt.close(fig)
    fig,ax=plt.subplots(figsize=(9.5,5.0),dpi=160)
    cnt=overview.loc[overview.matched_to_pal_name,'n_contact_rows_with_har_label'].to_numpy()
    bins=[0,1,2,5,10,20,50,100,200,500]
    ax.hist(cnt,bins=bins,edgecolor='white')
    ax.set_xscale('symlog',linthresh=1);ax.set_xticks([1,2,5,10,20,50,100,200]);ax.set_xticklabels(['1','2','5','10','20','50','100','200'])
    ax.set_xlabel('Pal hNSC interaction rows carrying each HAR label');ax.set_ylabel('Number of matched HAR labels')
    ax.set_title('Descriptive contact-record coverage for 174 matched labels',pad=15,fontweight='bold')
    ax.grid(axis='y',alpha=.18)
    ax.text(.99,-.22,'Counts depend on bait-fragment coverage and capture design; not biological effect sizes',transform=ax.transAxes,ha='right',color='.38',fontsize=9)
    fig.tight_layout();fig.savefig(outdir/'F2_Matched_HAR_Contact_Record_Distribution.png',dpi=330,bbox_inches='tight',facecolor='white');fig.savefig(outdir/'F2_Matched_HAR_Contact_Record_Distribution.pdf',bbox_inches='tight',facecolor='white');plt.close(fig)
    pd.DataFrame([
      {'category':'HAR-screen labels','count':180,'notes':'Names from 359 HAR-targeting guide records'},
      {'category':'Non-targeting control guides','count':6,'notes':'NTC1–NTC5 plus NTC_10x'},
      {'category':'Named control guides','count':5,'notes':'cont_-prefixed'},
      {'category':'Unique guide design gene annotations for HARs','count':164,'notes':'NOT functional validation'},
      {'category':'Pal source rows with screened HAR identifier','count':unique_pal_contact_rows,'notes':'Of 39,093 Pal hNSC rows, deduplicated over composite names'},
      {'category':'Pal hNSC contact rows overall','count':len(pal),'notes':'Includes other HARs and human gained enhancers'},
    ]).to_csv(outdir/'S7_Data_Roles_Not_Biological_Replicates.tsv',sep='\t',index=False)
    # Document protocol in English and Roman Urdu.
    msg=f"""# Stage 4 – Verified guide-design / chromatin-bait ID analysis

## Data provenance
- GSE270828 original `GSE270828_feature_README.csv`: SHA256 `{sha256(raw_guide)}`.
- Pal et al. original `HAR_interactions_hNSCs.txt`: SHA256 `{sha256(raw_pal)}`.
- Cross-study matching is a **HAR label-matching exercise**, not a perturbation-effect analysis or physical CRISPR guide-to-bait coordinate overlap test.

## Independent numeric audit
- GSE270828: **370** guide records; **359** targeting guides for **180** distinct HAR labels; **6 non-targeting and 5 named control guides**. **164** distinct design-gene annotations among the 180 screened HARs. Most HARs have 2 distinct guides (179/180), one has 1.
- Pal hNSC contact table: **39,093** source rows. Source includes HAR and HGE-labelled fragments.
- Unique HAR label matches: **109 exact bait-name**, **63 additional comma-separated composite bait names**, **2 additional `_sec`/`_tert` flanking labels**, and **6 absent**. In total **174/180 = {n_match/180:.1%}** show some name-level match. For a strict exact label only, the rate is **109/180 = {109/180:.1%}**. For core-name token matching excluding flank-only, **172/180 = {172/180:.1%}**.
- A total of **{unique_pal_contact_rows:,} distinct Pal source interaction rows** carry at least one screened HAR label, after matching composite names and flanking suffixes. Since composite rows may carry multiple HARs, per-HAR counts should **not be added** as independent contacts.
- No perturbation response statistics, guide efficiency, gene expression effect, gene promoter annotations, or original HAR interval coordinates are provided by this CSV. `target_gene_name` is the **design annotation**, not experimentally validated causal target.

## Six unmatched HAR labels
{', '.join(overview.loc[~overview.matched_to_pal_name,'har_name'].tolist())}.

## Gene-annotation caution illustrated by HAR181
In the original `GSE270828_feature_README.csv`, the two `HAR181` guides carry `target_gene_name=NXPE2` (design annotation), whereas the published Noble et al. 2024 screen paper reports experimental follow-up involving HAR181 and **CADM1** (https://pmc.ncbi.nlm.nih.gov/articles/PMC11244942/). This is a concrete reason **not** to interpret `target_gene_name` as a validated functional gene target or to equate design proximity with experimentally supported regulation. This does not mean the original annotations are erroneous: they answer different questions.

## Stage 3 distinction
The prior GSE292632 test of 106 distinct candidate regulatory intervals found 5 overlaps at Pal *OtherEnd* fragments (9 rows) and no bait-coordinate overlaps. The **9 source bait names in those rows do not overlap any of the 180 GSE270828 guide-screen HAR names**. The previous 5/106 and the new 174/180 quantify different evidence types and must never be combined into an experimental replication claim.

## Critical limitations
1. **Names** match, not yet physical guide-target intervals; the guide CSV lacks genomic target coordinates.
2. CHiCAGO contact scores refer to chromatin interactions, **not** expression-effect magnitudes, causal probabilities, or gene targets.
3. Flanking `_sec`/`_tert` names are lower-confidence correspondence, not proof that the central HAR element coincides with each captured fragment.
4. No cross-species comparative significance can be inferred from a single hNSC contact table.
5. False negatives cannot be inferred from missing identifiers or non-significant assays without power/coverage assessment.

## Proposed next verification
Acquire additional Dryad human-neuron and chimpanzee-NSC Capture-HiC contact tables (each <2MB) to test **label-level coverage differences**, with caution about unequal capture sensitivity. Then obtain actual GSE270828 per-guide or per-HAR gene expression *effect estimates* or an appropriate processed object, ideally authors' supplementary results, to benchmark regulatory predictions. GSE270828's ~2.2 GB RDS.gz count matrix would require a high-memory run and is not requested yet.
"""
    (outdir/'REPORT_Stage4_Scientific_Interpretation.md').write_text(msg,encoding='utf8')
    (outdir/'NEXT_ACTION_ROMAN_URDU.md').write_text("""# Aap ka next step

Bhai, guide-file analysis complete hai. Ab Dryad ki original deposit se **2 small text files** download karke ek ZIP mein upload karein:
1. `HAR_interactions_human_neurons.txt` (~1.45 MB)
2. `HAR_interactions_cNSCs.txt` (~1.78 MB)

Official page: https://datadryad.org/dataset/doi:10.5061/dryad.c59zw3rkj

Website par `Download full dataset` ka option bhi available hai (~5.87 MB). Woh full ZIP upload karna sabse asaan hai: is mein human NSC wali already-analysed file bhi hogi, koi issue nahi.

In files se hum 180 HAR labels ka hNSC-versus-human neuron-versus-chimp NSC **name/coverage comparison** kar sakein ge. Woh causal inference ya experimental expression validation nahin hogi. Actual expression effects ke liye alag processed GSE270828 data chahiye; 2.2 GB raw matrix abhi download na karein.
""",encoding='utf8')
    print(json.dumps(summary,indent=2));return outdir

if __name__=='__main__':
    a=argparse.ArgumentParser();a.add_argument('--guide-zip',default='/mnt/data/GSE270828_Full_Guide_Reference_FOR_REVIEW.zip');a.add_argument('--pal',default='/mnt/data/HAR_interactions_hNSCs.txt');a.add_argument('--stage3',default='/mnt/data/HAR_Stage3_Pal_Overlap_Audit/S2_Nine_Spatial_Coincidences_With_Pal_hNSC_Contacts.tsv');a.add_argument('--out',default='/mnt/data/HAR_Stage4_Guide_Pal_Integration')
    p=a.parse_args();run(p.guide_zip,p.pal,p.out,p.stage3)
