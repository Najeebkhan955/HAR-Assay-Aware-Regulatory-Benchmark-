# Aap ka next step

Bhai, guide-file analysis complete hai. Ab Dryad ki original deposit se **2 small text files** download karke ek ZIP mein upload karein:
1. `HAR_interactions_human_neurons.txt` (~1.45 MB)
2. `HAR_interactions_cNSCs.txt` (~1.78 MB)

Official page: https://datadryad.org/dataset/doi:10.5061/dryad.c59zw3rkj

Website par `Download full dataset` ka option bhi available hai (~5.87 MB). Woh full ZIP upload karna sabse asaan hai: is mein human NSC wali already-analysed file bhi hogi, koi issue nahi.

In files se hum 180 HAR labels ka hNSC-versus-human neuron-versus-chimp NSC **name/coverage comparison** kar sakein ge. Woh causal inference ya experimental expression validation nahin hogi. Actual expression effects ke liye alag processed GSE270828 data chahiye; 2.2 GB raw matrix abhi download na karein.
