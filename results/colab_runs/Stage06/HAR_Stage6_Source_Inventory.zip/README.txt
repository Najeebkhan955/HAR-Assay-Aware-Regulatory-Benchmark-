This inventory is NOT an effect analysis. Read file names and source pages before interpreting content.

If listing fails, open https://www.ncbi.nlm.nih.gov/geo/query/acc.cgi?acc=GSE270828 in a browser and provide a screenshot of the Supplementary files area.

Do not download raw multi-GB RDS/H5AD until an analysis plan is confirmed.
