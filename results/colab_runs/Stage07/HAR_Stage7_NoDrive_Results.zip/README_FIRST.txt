HAR Stage 7 — Direct original NCBI GEO files, no Google Drive.
Open STATUS.json to identify completed/blocked stages.
This is metadata QC only; gene-level perturbation expression effects have NOT been computed.
A failed large download or failed RDS extraction does NOT imply missing biological data.
